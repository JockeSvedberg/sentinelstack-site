#!/usr/bin/env python3
import argparse
import os
from datetime import datetime
from fpdf import FPDF

def generate_pdf(client_name, data):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)
    pdf.cell(200, 10, txt=f"AI Compliance Package – {client_name}", ln=True, align='C')
    pdf.ln(10)
    for line in data.split("\n"):
        pdf.multi_cell(0, 10, line)
    pdf_path = f"{client_name}_AI_Compliance_Report.pdf"
    pdf.output(pdf_path)
    return pdf_path

def run_generate(args):
    print("📄 Genererar dokumentpaket för:", args.name)
    profile_data = f"Generated package for {args.name} at {datetime.now()}\n"
    with open(f"{args.name}_compliance_package.txt", "w") as f:
        f.write(profile_data)
    pdf_path = generate_pdf(args.name, profile_data)
    print(f"✔️ PDF skapad: {pdf_path}")

def main():
    parser = argparse.ArgumentParser(prog="sentinelstack", description="AI Compliance CLI – SentinelStack AB")
    subparsers = parser.add_subparsers(dest="command", required=True)
    p_generate = subparsers.add_parser("generate", help="Generera dokumentpaket")
    p_generate.add_argument("--name", required=True, help="Klientnamn")
    p_generate.set_defaults(func=run_generate)
    args = parser.parse_args()
    args.func(args)

if __name__ == "__main__":
    main()
